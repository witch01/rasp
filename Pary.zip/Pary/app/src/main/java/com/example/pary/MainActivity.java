package com.example.pary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

import lalala.RecyclerViewAdapter;

public class MainActivity extends AppCompatActivity {

    ArrayList<Model> days = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        GridLayoutManager glm = new GridLayoutManager(this, 1);
        glm.setOrientation(RecyclerView.VERTICAL);


        setData();

        RecyclerView recyclerView = findViewById(R.id.recycleView);

        recyclerView.setLayoutManager(glm);
        RecyclerViewAdapter adapter=new RecyclerViewAdapter(this, days);
        recyclerView.setAdapter(adapter);
    }

    private void setData() {
        days.add(new Model("ПОНЕДЕЛЬНИК Нахимовский", "", "Системное програм-\nмирование\n\nТехнология разработки\n и защиты баз данных", "Разработка программных\nмодулей",
                "Разработка мобильных\nприложений\n\nРазработка программных\nмодулей", "Физическая культура",
                "", "О.В.Копылов\n\n\nГ.Ю.Волкова", "А.А.Шимбирёв", "А.О.Лясников\n\n\nА.Ю.Бушин", "А.В.Андрюков"));
        days.add(new Model("ВТОРНИК", "ПРАКТИКА", "ПРАКТИКА", "ПРАКТИКА",
                "ПРАКТИКА", "ПРАКТИКА",
                "", "", "", "", ""));
        days.add(new Model("СРЕДА", "ПРАКТИКА", "ПРАКТИКА", "ПРАКТИКА",
                "ПРАКТИКА", "ПРАКТИКА",
                "", "", "", "", ""));
        days.add(new Model("ЧЕТВЕРГ Нежинская", "Инструментальные средс-\nтва разработки\nПО ", "Технология разработки прог-\nраммного обеспечения ", "Иностранный язык в профес-\nсиональной\nдеятельности ", "Технология\nразработки и защиты\nБД ",
                "", "Ю.В. Севастьянов", "Л.А. Соколова", "А.Д. Завьялова,\nА.Ю. Дымская", "Г.Ю. Волкова", ""));
        days.add(new Model("ПЯТНИЦА Нахимовский", "", "Системное\nпрограммирование", "Разработка\nпрограммных модулей\nПО\n\nТехнология разработки\nи защиты баз данных",
                "Технология разработки\nпрограммного обеспечения\n\nИнструментальные\nсредства\nразработки ПО", "Разработка мобильных\nприложения",
                "", "О.В. Копылов", "А.Ю. Бушин", "Л.А. Соколова\n\n\nЮ.В. Севастьянов", "А.О. Лясников"));
    }
}
